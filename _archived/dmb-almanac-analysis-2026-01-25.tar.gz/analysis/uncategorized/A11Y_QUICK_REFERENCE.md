# Accessibility Quick Reference Card

**DMB Almanac Components - WCAG 2.1 AA Compliant**

Print this page or save as bookmark for quick reference.

---

## Component Quick Start

### ErrorBoundary
```svelte
<ErrorBoundary onError={(e) => console.error(e)}>
  <MyComponent />
</ErrorBoundary>
```
**Key Features**: Immediate error announcement, keyboard accessible
**Screen Reader**: "Alert. Something went wrong. [Error details]"

### Dropdown
```svelte
<Dropdown id="menu" label="Actions">
  <button role="menuitem" onclick={handleAction1}>Action 1</button>
  <button role="menuitem" onclick={handleAction2}>Action 2</button>
</Dropdown>
```
**Key Features**: Arrow key navigation, focus trap, Escape to close
**Keyboard**: Tab, Space/Enter to open, ↓↑ to navigate, Escape to close
**Screen Reader**: "Menu button, popup menu, expanded. Menu items..."

### Tooltip
```svelte
<Tooltip id="help" content="Click for more info">
  <button aria-label="Help">?</button>
</Tooltip>
```
**Key Features**: Focus activated, keyboard dismissible
**Screen Reader**: "Help button, described by help tooltip content"

### Table
```svelte
<Table
  data={shows}
  columns={columns}
  caption="2024 Concert Schedule"
  summary="All scheduled shows with dates and venues"
/>
```
**Key Features**: Caption support, sortable columns, keyboard accessible
**Screen Reader**: "Table. 2024 Concert Schedule. [Column headers and data]"

### Pagination
```svelte
<Pagination
  currentPage={page}
  totalPages={totalPages}
  onPageChange={(p) => page = p}
/>
```
**Key Features**: Current page marked, disabled at boundaries
**Screen Reader**: "Pagination navigation. Page 3, current page"

### UpdatePrompt
```svelte
<UpdatePrompt />
```
**Key Features**: Self-contained, focus on primary action, Escape dismissible
**Screen Reader**: "Alert dialog. New version available. [Actions]"

---

## Keyboard Shortcuts

| Component | Key | Action |
|-----------|-----|--------|
| All | Tab | Move to next element |
| All | Shift+Tab | Move to previous element |
| Button | Enter, Space | Activate |
| Dropdown | Space, Enter | Toggle menu |
| Dropdown | ↓ | Next item |
| Dropdown | ↑ | Previous item |
| Dropdown | Home | First item |
| Dropdown | End | Last item |
| Dropdown | Escape | Close, return focus |
| Table | Enter, Space | Sort (header) or select (row) |
| Tooltip | Escape | Close tooltip |
| Modal | Escape | Dismiss dialog |

---

## ARIA Attributes Cheat Sheet

### Required on Components

```svelte
<!-- ErrorBoundary -->
role="alert"
aria-live="assertive"
aria-describedby

<!-- Dropdown -->
aria-haspopup="menu"
aria-expanded={isOpen}
aria-controls
role="menu" (on menu)
role="menuitem" (on items)

<!-- Tooltip -->
aria-describedby
role="tooltip"

<!-- Table -->
role="table"
aria-label (summary)
scope="col" (headers)
aria-sort (sortable headers)
aria-current="page" (pagination)

<!-- Modal/Dialog -->
role="alertdialog"
aria-labelledby
aria-describedby
```

---

## Focus Styles

All components have visible focus indicators:
```css
.element:focus-visible {
  outline: 2px solid var(--color-primary);
  outline-offset: 2px;
  box-shadow: 0 0 0 4px rgba(color, 0.2);
}

/* High contrast mode */
@media (forced-colors: active) {
  .element:focus-visible {
    outline: 3px solid Highlight;
  }
}
```

---

## Screen Reader Checklist

Before deploying:

- [ ] Tab through page with screen reader
- [ ] All interactive elements announced
- [ ] Form labels associated with inputs
- [ ] Error messages announced
- [ ] Status changes announced
- [ ] Table headers announced per row
- [ ] Skip links work
- [ ] Dialogs announced as dialogs
- [ ] Headings create logical outline

---

## Common Mistakes ❌ → Fixes ✓

### Missing role="menuitem"
```svelte
❌ <Dropdown><button>Item</button></Dropdown>
✓ <Dropdown><button role="menuitem">Item</button></Dropdown>
```

### No Table Caption
```svelte
❌ <Table data={data} columns={cols} />
✓ <Table data={data} columns={cols} caption="2024 Data" />
```

### Button Not Labeled
```svelte
❌ <button>?</button>
✓ <button aria-label="Help">?</button>
```

### Outline Removed
```svelte
❌ button { outline: none; }
✓ button:focus-visible { outline: 2px solid blue; }
```

### No Focus Management
```svelte
❌ // Focus lost after modal opens
✓ modal.querySelector('button').focus();
```

---

## Testing with Screen Readers

### VoiceOver (macOS)
```
Enable: System Preferences > Accessibility > VoiceOver
Controls: Ctrl+Option + Arrow keys
Activate: Ctrl+Option + Space
Help: Ctrl+Option + ?
```

### NVDA (Windows)
```
Enable: nvaccess.org/download
Controls: Arrow keys
Activate: Enter or Space
Speech: Insert+Down Arrow
```

### JAWS (Windows)
```
Enable: Freedom Scientific (paid)
Controls: Arrow keys
Activate: Enter
Forms Mode: Enter (turn on in form fields)
```

---

## Browser DevTools

### Chrome/Edge
**Elements > Accessibility Tree**
- Shows ARIA roles and attributes
- Reveals what screen readers see

### Firefox
**Inspector > Accessibility Tab**
- Checks ARIA usage
- Shows text alternatives

### Safari
**Develop > Accessibility Inspector**
- Audits accessibility properties

---

## Color Contrast

Minimum ratios for WCAG AA:
- **Normal text**: 4.5:1
- **Large text** (18pt+ or 14pt+ bold): 3:1
- **Graphical objects**: 3:1

Use: [WCAG Contrast Checker](https://webaim.org/resources/contrastchecker/)

---

## Focus Order

For optimal experience, ensure:
1. Logical left-to-right, top-to-bottom flow
2. No focus jumps to middle of page
3. Related fields grouped together
4. Tab order matches visual layout

---

## Text Alternatives

| Content Type | Alternative |
|--------------|------------|
| Image | `alt="description"` |
| Icon | `aria-label` or `aria-hidden="true"` |
| Button | Text content or `aria-label` |
| Form input | `<label>` element |
| Table | `<caption>` element |

---

## Motion Preferences

Respect user preferences:
```css
@media (prefers-reduced-motion: reduce) {
  * {
    transition: none !important;
    animation: none !important;
  }
}
```

---

## Resources

- **WCAG 2.1**: https://www.w3.org/WAI/WCAG21/quickref/
- **ARIA APG**: https://www.w3.org/WAI/ARIA/apg/
- **axe DevTools**: https://www.deque.com/axe/devtools/
- **Lighthouse**: DevTools > Lighthouse > Accessibility
- **WAVE**: https://wave.webaim.org/

---

## Quick Audit Checklist

### Five-Minute Audit
- [ ] Tab through page - can reach all elements?
- [ ] Focus visible - can see where you are?
- [ ] Page zoom to 200% - content readable?
- [ ] No color alone - other visual cues?
- [ ] Dark background - text still readable?

### Keyboard Test
- [ ] Tab navigates forward ✓
- [ ] Shift+Tab navigates backward ✓
- [ ] Enter/Space activate buttons ✓
- [ ] Escape closes modals ✓
- [ ] No keyboard traps ✓

### Screen Reader Test
- [ ] Page makes sense when read linearly ✓
- [ ] Headings create logical outline ✓
- [ ] Form labels associated with inputs ✓
- [ ] Images have alt text or aria-hidden ✓
- [ ] Error messages announced ✓

---

## Getting Help

For detailed information:
- **Comprehensive Guide**: ACCESSIBILITY_GUIDE.md
- **Developer Checklist**: COMPONENT_A11Y_CHECKLIST.md
- **Audit Report**: A11Y_FIXES_SUMMARY.md
- **Test Results**: A11Y_TEST_REPORT.md

---

## Key Takeaways

1. **Semantic HTML First** - Use native elements before ARIA
2. **Keyboard Always** - All functionality via keyboard
3. **Focus Clear** - Always visible, never remove
4. **Test Real** - Screen readers, keyboard, zoom
5. **Document Well** - Help others maintain accessibility

---

**Remember**: Accessibility benefits everyone. More users. Better UX. Legal compliance.

Last Updated: 2025-01-22
