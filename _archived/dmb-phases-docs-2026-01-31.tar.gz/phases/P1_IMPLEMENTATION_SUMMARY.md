# P1 (High Priority) Implementation Summary

## Overview

This document summarizes the P1 (High Priority) tasks from the comprehensive debug & audit plan. These tasks are not blocking production but provide significant value in performance, user experience, and system observability.

**Implementation Status as of January 25, 2026:**

1. ✅ **Push Notification Real Functionality** - **COMPLETE**
2. ✅ **WASM Worker Compatibility Fix** - **Detailed Plan Created**
3. 📋 **Image Lazy Loading** - Implementation Plan Below
4. 📋 **Service Worker Update Notifications** - Implementation Plan Below
5. 📋 **Database Query Indexes** - Implementation Plan Below
6. 📋 **Bundle Size Monitoring** - Implementation Plan Below

---

## 1. Push Notifications ✅ COMPLETE

**Status:** Fully implemented and production-ready
**Documentation:** `PUSH_NOTIFICATIONS_IMPLEMENTATION.md`

### What Was Delivered

- **Server-Side Database** - SQLite storage for push subscriptions
- **Real Subscription Storage** - `/api/push-subscribe` endpoint with CSRF protection
- **Real Push Sending** - `/api/push-send` with web-push library and VAPID
- **Unsubscribe Functionality** - `/api/push-unsubscribe` endpoint
- **Setup Script** - `npm run setup:push` generates keys and initializes DB
- **Comprehensive Documentation** - Setup guide, API reference, testing procedures

### Files Modified/Created

- NEW: `src/lib/db/server/push-subscriptions.ts` (448 lines)
- NEW: `scripts/setup-push-notifications.ts` (155 lines)
- NEW: `PUSH_NOTIFICATIONS_IMPLEMENTATION.md` (520 lines)
- MODIFIED: `src/routes/api/push-subscribe/+server.ts`
- MODIFIED: `src/routes/api/push-send/+server.ts`
- MODIFIED: `src/routes/api/push-unsubscribe/+server.ts`
- MODIFIED: `package.json` (added setup:push script)
- MODIFIED: `package-lock.json` (added web-push ^3.6.7)

### Next Steps

Run setup to generate VAPID keys:
```bash
npm run setup:push
```

---

## 2. WASM Worker Fix ✅ PLAN COMPLETE

**Status:** Comprehensive implementation plan created
**Documentation:** `WASM_WORKER_FIX_PLAN.md`

### Problem

Worker uses raw `WebAssembly.instantiate()` which doesn't work with wasm-bindgen generated modules, forcing fallback to slow JavaScript implementations.

### Solution

Use ES module workers with wasm-bindgen generated JS glue code:
- Create `wasm-worker-esm.ts` that imports generated module
- Update bridge to use `new Worker(url, { type: 'module' })`
- Enable Vite worker plugin configuration
- Browser support: Chrome 80+, Firefox 114+, Safari 15+

### Expected Performance Improvement

- Global search: **5x faster** (100ms → 20ms)
- Liberation list: **4x faster** (300ms → 75ms)
- Segue analysis: **5x faster** (800ms → 160ms)

### Implementation Effort

**Estimated:** 4-6 hours including testing

### Files to Create/Modify

- NEW: `src/lib/wasm/wasm-worker-esm.ts` (200 lines)
- MODIFIED: `src/lib/wasm/bridge.ts` (update worker initialization)
- MODIFIED: `vite.config.ts` (enable ES module workers)
- NEW: `scripts/test-wasm-worker.ts` (testing script)

---

## 3. Image Lazy Loading 📋 PLAN

**Priority:** P1 - High
**Estimated Effort:** 2-3 hours

### Problem

All images load eagerly regardless of viewport position, increasing initial page load time and bandwidth usage. Audit identified this affects:
- Venue images
- Artist photos
- Album covers
- Tour posters

### Solution

Add `loading="lazy"` and `decoding="async"` attributes to all `<img>` tags.

### Implementation Steps

#### 1. Find All Image Elements

```bash
cd /Users/louisherman/ClaudeCodeProjects/projects/dmb-almanac/app
grep -r "<img" src/lib/components src/routes --include="*.svelte" > images-audit.txt
```

#### 2. Update Image Components

**Pattern to find:**
```svelte
<img src={image.url} alt={image.alt} class="venue-image" />
```

**Replace with:**
```svelte
<img
  src={image.url}
  alt={image.alt}
  loading="lazy"
  decoding="async"
  class="venue-image"
/>
```

#### 3. Add Blur-Up Placeholder for LCP Images

For above-the-fold images (hero images, featured content):

```svelte
<script>
  let imageLoaded = false;
</script>

<div class="image-container">
  {#if !imageLoaded}
    <div class="placeholder" style="background-color: {dominantColor}" />
  {/if}
  <img
    src={image.url}
    alt={image.alt}
    loading="eager"
    decoding="async"
    class="hero-image"
    class:loaded={imageLoaded}
    on:load={() => imageLoaded = true}
  />
</div>

<style>
  .image-container {
    position: relative;
    overflow: hidden;
  }

  .placeholder {
    position: absolute;
    inset: 0;
    transition: opacity 0.3s;
  }

  .hero-image {
    opacity: 0;
    transition: opacity 0.3s;
  }

  .hero-image.loaded {
    opacity: 1;
  }
</style>
```

#### 4. Add Responsive `srcset`

For images displayed at multiple sizes:

```svelte
<img
  src={image.url}
  srcset="
    {image.url}?w=320 320w,
    {image.url}?w=640 640w,
    {image.url}?w=1024 1024w
  "
  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
  alt={image.alt}
  loading="lazy"
  decoding="async"
/>
```

### Verification

**Before:**
- Run Lighthouse audit
- Note LCP score and total image bytes transferred
- Check Network tab for image load timing

**After:**
- Re-run Lighthouse audit
- **Expected:** LCP improvement of 20-30%
- **Expected:** Initial page load 30-40% smaller
- Verify images below fold only load when scrolled into view

### Files to Modify

Search results will identify specific files. Common locations:
- `src/lib/components/ui/VenueCard.svelte`
- `src/lib/components/ui/ShowCard.svelte`
- `src/lib/components/ui/SongCard.svelte`
- `src/routes/venues/[id]/+page.svelte`
- `src/routes/shows/[id]/+page.svelte`

---

## 4. Service Worker Update Notifications 📋 PLAN

**Priority:** P1 - High
**Estimated Effort:** 3-4 hours

### Problem

Users never notified when new service worker version is available, causing stale code to run indefinitely until manual refresh.

### Solution

Implement update notification UI with "Update Now" and "Dismiss" buttons.

### Implementation Steps

#### 1. Update PWA Store

**File:** `src/lib/stores/pwa.ts`

Add update detection logic:

```typescript
import { writable } from 'svelte/store';

export const updateAvailable = writable(false);
export const waitingWorker = writable<ServiceWorker | null>(null);

export function initializeServiceWorkerUpdates(registration: ServiceWorkerRegistration) {
  // Listen for updates
  registration.addEventListener('updatefound', () => {
    const newWorker = registration.installing;

    newWorker?.addEventListener('statechange', () => {
      if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
        // New version available
        updateAvailable.set(true);
        waitingWorker.set(newWorker);
      }
    });
  });

  // Check for updates periodically (every 5 minutes)
  setInterval(() => {
    registration.update().catch(console.error);
  }, 5 * 60 * 1000);
}

export function applyUpdate() {
  const worker = get(waitingWorker);
  if (worker) {
    worker.postMessage({ type: 'SKIP_WAITING' });
  }
}
```

#### 2. Update Service Worker

**File:** `static/sw.js` or service worker file

Add message listener:

```javascript
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
```

#### 3. Create Update Banner Component

**File:** `src/lib/components/pwa/UpdateBanner.svelte`

```svelte
<script lang="ts">
  import { updateAvailable } from '$lib/stores/pwa';
  import { applyUpdate } from '$lib/stores/pwa';

  let dismissed = false;

  function handleUpdate() {
    applyUpdate();
    // Page will reload automatically when new SW activates
  }

  function handleDismiss() {
    dismissed = true;
    // Update will apply on next page load
  }
</script>

{#if $updateAvailable && !dismissed}
  <div class="update-banner" role="alert" aria-live="polite">
    <div class="update-content">
      <svg class="update-icon" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
      </svg>
      <div class="update-text">
        <h3>New Version Available</h3>
        <p>An update is ready. Refresh to get the latest features and fixes.</p>
      </div>
    </div>

    <div class="update-actions">
      <button
        class="btn-update"
        on:click={handleUpdate}
        type="button"
      >
        Update Now
      </button>
      <button
        class="btn-dismiss"
        on:click={handleDismiss}
        type="button"
      >
        Later
      </button>
    </div>
  </div>
{/if}

<style>
  .update-banner {
    position: fixed;
    bottom: var(--space-4, 1rem);
    left: var(--space-4, 1rem);
    right: var(--space-4, 1rem);
    max-width: 600px;
    margin: 0 auto;
    background: var(--color-primary-500, #3b82f6);
    color: white;
    padding: var(--space-4, 1rem);
    border-radius: var(--radius-lg, 0.5rem);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    z-index: 9999;
    animation: slide-up 0.3s ease-out;
  }

  @keyframes slide-up {
    from {
      transform: translateY(100%);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }

  .update-content {
    display: flex;
    gap: var(--space-3, 0.75rem);
    align-items: flex-start;
    margin-bottom: var(--space-3, 0.75rem);
  }

  .update-icon {
    width: 24px;
    height: 24px;
    fill: currentColor;
    flex-shrink: 0;
  }

  .update-text h3 {
    margin: 0 0 var(--space-1, 0.25rem);
    font-size: var(--text-base, 1rem);
    font-weight: var(--font-semibold, 600);
  }

  .update-text p {
    margin: 0;
    font-size: var(--text-sm, 0.875rem);
    opacity: 0.9;
  }

  .update-actions {
    display: flex;
    gap: var(--space-2, 0.5rem);
    justify-content: flex-end;
  }

  .btn-update,
  .btn-dismiss {
    padding: var(--space-2, 0.5rem) var(--space-4, 1rem);
    border-radius: var(--radius-md, 0.375rem);
    font-size: var(--text-sm, 0.875rem);
    font-weight: var(--font-medium, 500);
    cursor: pointer;
    border: none;
    transition: all 0.2s;
  }

  .btn-update {
    background: white;
    color: var(--color-primary-600, #2563eb);
  }

  .btn-update:hover {
    background: var(--color-gray-100, #f3f4f6);
  }

  .btn-dismiss {
    background: transparent;
    color: white;
    border: 1px solid rgba(255, 255, 255, 0.3);
  }

  .btn-dismiss:hover {
    background: rgba(255, 255, 255, 0.1);
  }
</style>
```

#### 4. Add to Root Layout

**File:** `src/routes/+layout.svelte`

```svelte
<script>
  import { browser } from '$app/environment';
  import { initializeServiceWorkerUpdates } from '$lib/stores/pwa';
  import UpdateBanner from '$lib/components/pwa/UpdateBanner.svelte';

  if (browser && 'serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then((registration) => {
      initializeServiceWorkerUpdates(registration);
    });

    // Reload page when new SW activates
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      window.location.reload();
    });
  }
</script>

<UpdateBanner />

<slot />
```

### Verification

1. **Deploy new version** with changed precache manifest
2. **Open app** in browser with old version
3. **Wait 5 seconds** for update check
4. **Verify banner appears** at bottom of screen
5. **Click "Update Now"** → page should reload
6. **Verify new version** is running (check version in footer/about)

### Files to Create/Modify

- MODIFIED: `src/lib/stores/pwa.ts` (add update detection)
- NEW: `src/lib/components/pwa/UpdateBanner.svelte` (UI component)
- MODIFIED: `src/routes/+layout.svelte` (add UpdateBanner)
- MODIFIED: `static/sw.js` (add SKIP_WAITING handler)

---

## 5. Database Query Indexes 📋 PLAN

**Priority:** P1 - High
**Estimated Effort:** 2-3 hours

### Problem

Missing compound indexes for common aggregation queries causes slow performance on large datasets:
- Liberation list queries scan entire setlistEntries table
- Venue filtering lacks compound index for efficient lookup
- Date range queries don't utilize indexes

### Solution

Add compound indexes to Dexie schema for frequently-used query patterns.

### Implementation Steps

#### 1. Analyze Current Queries

**Common query patterns:**

```typescript
// Liberation list - needs [isLiberated+year] index
db.setlistEntries
  .where('isLiberated').equals(true)
  .and(entry => entry.year === targetYear)
  .toArray();

// Venue shows - needs [venueId+date] index
db.shows
  .where('venueId').equals(venueId)
  .and(show => show.date >= startDate && show.date <= endDate)
  .toArray();

// Song performances by year - needs [songId+year] index
db.performances
  .where('songId').equals(songId)
  .and(perf => perf.year === year)
  .toArray();
```

#### 2. Update Dexie Schema

**File:** `src/lib/db/dexie/schema.ts`

```typescript
// BEFORE
shows: '++id, date, venueId, tourId, ...rest',
setlistEntries: '++id, showId, songId, position, [showId+position], ...rest',
performances: '++id, showId, songId, ...rest',

// AFTER - Add compound indexes
shows: '++id, date, venueId, tourId, [venueId+date], ...rest',
setlistEntries: '++id, showId, songId, position, [showId+position], [songId+year], [isLiberated+year], ...rest',
performances: '++id, showId, songId, [songId+year], ...rest',
```

#### 3. Implement Migration

**File:** `src/lib/db/dexie/db.ts`

Bump schema version and add upgrade logic:

```typescript
export class DmbAlmanacDb extends Dexie {
  // ...existing table declarations

  constructor() {
    super('dmb-almanac');

    // Previous version (current)
    this.version(14).stores({
      shows: '++id, date, venueId, tourId, ...rest',
      setlistEntries: '++id, showId, songId, position, [showId+position], ...rest',
      // ...other tables
    });

    // NEW VERSION 15 - Add compound indexes
    this.version(15).stores({
      shows: '++id, date, venueId, tourId, [venueId+date], ...rest',
      setlistEntries: '++id, showId, songId, position, [showId+position], [songId+year], [isLiberated+year], ...rest',
      performances: '++id, showId, songId, [songId+year], ...rest',
      // ...other tables unchanged
    }).upgrade(async (trans) => {
      // Indexes added automatically by Dexie
      // No data migration needed - just rebuild indexes
      console.log('Rebuilt indexes for version 15');
    });
  }
}
```

#### 4. Update Query Code

**File:** `src/lib/db/dexie/data-loader.ts`

Use new compound indexes:

```typescript
// Liberation list query - now uses [isLiberated+year] index
async getLiberationList(year: number): Promise<LiberationEntry[]> {
  return this.setlistEntries
    .where('[isLiberated+year]')
    .equals([1, year])  // 1 = true for boolean index
    .toArray();
}

// Venue shows query - now uses [venueId+date] index
async getVenueShows(venueId: number, startDate: string, endDate: string): Promise<Show[]> {
  return this.shows
    .where('[venueId+date]')
    .between([venueId, startDate], [venueId, endDate], true, true)
    .toArray();
}

// Song performances by year - now uses [songId+year] index
async getSongPerformancesByYear(songId: number, year: number): Promise<Performance[]> {
  return this.performances
    .where('[songId+year]')
    .equals([songId, year])
    .toArray();
}
```

### Verification

#### Performance Testing

**Before (no compound indexes):**
```typescript
console.time('liberation-list');
const results = await db.getLiberationList(2024);
console.timeEnd('liberation-list');
// Expected: 200-400ms for 10k+ entries
```

**After (with compound indexes):**
```typescript
console.time('liberation-list');
const results = await db.getLiberationList(2024);
console.timeEnd('liberation-list');
// Expected: 10-30ms (10-20x faster)
```

#### Index Verification

Use Chrome DevTools:
1. Open DevTools > Application > IndexedDB
2. Expand database > Select table
3. Verify compound indexes appear in index list
4. Check query plans use indexes (no full table scans)

### Files to Modify

- MODIFIED: `src/lib/db/dexie/schema.ts` (add compound indexes)
- MODIFIED: `src/lib/db/dexie/db.ts` (version 15 migration)
- MODIFIED: `src/lib/db/dexie/data-loader.ts` (optimize queries)

---

## 6. Bundle Size Monitoring 📋 PLAN

**Priority:** P1 - High
**Estimated Effort:** 3-4 hours

### Problem

No automated tracking of bundle size over time, risking performance regression as features are added.

### Solution

Add `vite-plugin-bundle-analyzer` with size budgets and CI checks.

### Implementation Steps

#### 1. Install Dependencies

```bash
npm install --save-dev vite-plugin-visualizer @size-limit/preset-app
```

#### 2. Add Vite Plugin

**File:** `vite.config.ts`

```typescript
import { defineConfig } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import { visualizer } from 'vite-plugin-visualizer';

export default defineConfig({
  plugins: [
    svelte(),
    visualizer({
      filename: './bundle-stats.html',
      open: false,
      gzipSize: true,
      brotliSize: true,
      template: 'treemap', // or 'sunburst', 'network'
    })
  ],
  build: {
    rollupOptions: {
      output: {
        // Chunk splitting for better caching
        manualChunks: {
          vendor: ['svelte', 'dexie'],
          wasm: ['./src/lib/wasm/bridge.ts'],
          charts: ['d3-scale', 'd3-axis', 'd3-selection']
        }
      }
    }
  }
});
```

#### 3. Add Size Budgets

**File:** `.size-limit.json`

```json
[
  {
    "name": "Main Bundle",
    "path": "build/_app/immutable/chunks/main.*.js",
    "limit": "150 KB",
    "gzip": true
  },
  {
    "name": "Vendor Bundle",
    "path": "build/_app/immutable/chunks/vendor.*.js",
    "limit": "300 KB",
    "gzip": true
  },
  {
    "name": "WASM Bundle",
    "path": "build/_app/immutable/chunks/wasm.*.js",
    "limit": "50 KB",
    "gzip": true
  },
  {
    "name": "Charts Bundle",
    "path": "build/_app/immutable/chunks/charts.*.js",
    "limit": "100 KB",
    "gzip": true
  },
  {
    "name": "Total JavaScript",
    "path": "build/_app/immutable/chunks/*.js",
    "limit": "600 KB",
    "gzip": true
  }
]
```

#### 4. Add NPM Scripts

**File:** `package.json`

```json
{
  "scripts": {
    "analyze": "vite build && open bundle-stats.html",
    "size": "size-limit",
    "size:why": "size-limit --why"
  }
}
```

#### 5. Add GitHub Actions CI Check

**File:** `.github/workflows/bundle-size.yml`

```yaml
name: Bundle Size Check

on:
  pull_request:
    branches: [main]

jobs:
  check-size:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Build WASM modules
        run: npm run wasm:build

      - name: Build application
        run: npm run build

      - name: Check bundle size
        run: npm run size

      - name: Report bundle size
        uses: andresz1/size-limit-action@v1
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
```

#### 6. Create Bundle Analysis Dashboard

**File:** `scripts/analyze-bundle.ts`

```typescript
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

interface BundleStats {
  file: string;
  size: number;
  gzipSize: number;
}

function analyzeBundleDir(dir: string): BundleStats[] {
  const stats: BundleStats[] = [];

  function walk(currentDir: string) {
    const files = readdirSync(currentDir);

    for (const file of files) {
      const filePath = join(currentDir, file);
      const stat = statSync(filePath);

      if (stat.isDirectory()) {
        walk(filePath);
      } else if (file.endsWith('.js') || file.endsWith('.css')) {
        const content = readFileSync(filePath);
        const gzipSize = estimateGzipSize(content);

        stats.push({
          file: filePath.replace(process.cwd(), ''),
          size: stat.size,
          gzipSize
        });
      }
    }
  }

  walk(dir);
  return stats;
}

function estimateGzipSize(content: Buffer): number {
  // Rough estimate: gzip typically achieves 70-80% compression for JS
  return Math.floor(content.length * 0.25);
}

// Run analysis
const buildDir = join(process.cwd(), 'build');
const stats = analyzeBundleDir(buildDir);

// Sort by size
stats.sort((a, b) => b.size - a.size);

// Print results
console.log('Bundle Size Analysis:');
console.log('='.repeat(80));

let totalSize = 0;
let totalGzip = 0;

for (const { file, size, gzipSize } of stats) {
  totalSize += size;
  totalGzip += gzipSize;

  console.log(`${file}`);
  console.log(`  Size: ${(size / 1024).toFixed(2)} KB`);
  console.log(`  Gzip: ${(gzipSize / 1024).toFixed(2)} KB`);
  console.log('');
}

console.log('='.repeat(80));
console.log(`Total: ${(totalSize / 1024).toFixed(2)} KB (${(totalGzip / 1024).toFixed(2)} KB gzipped)`);

// Check against budgets
const budgetExceeded = totalGzip > 600 * 1024; // 600 KB budget
if (budgetExceeded) {
  console.error('❌ Bundle size exceeds budget!');
  process.exit(1);
} else {
  console.log('✅ Bundle size within budget');
}
```

### Usage

**Local development:**
```bash
# Build and view bundle visualization
npm run analyze

# Check against size limits
npm run size

# Understand why bundle is large
npm run size:why
```

**CI/CD:**
- Pull requests automatically check bundle size
- Fails if any budget is exceeded
- Comments on PR with size comparison

### Verification

1. **Run initial analysis:**
   ```bash
   npm run analyze
   ```

2. **View treemap visualization** - Opens `bundle-stats.html` in browser
   - Identify largest chunks
   - Check for duplicate dependencies
   - Verify code splitting is effective

3. **Check size budgets:**
   ```bash
   npm run size
   ```
   Should pass all checks initially

4. **Test CI integration:**
   - Create PR that adds a large dependency
   - Verify CI job fails with budget exceeded
   - Verify PR comment shows size increase

### Files to Create/Modify

- MODIFIED: `vite.config.ts` (add visualizer plugin)
- NEW: `.size-limit.json` (size budgets)
- NEW: `.github/workflows/bundle-size.yml` (CI check)
- NEW: `scripts/analyze-bundle.ts` (custom analysis)
- MODIFIED: `package.json` (add scripts)

---

## Implementation Priority

If implementing these tasks sequentially, recommended order:

1. **Image Lazy Loading** (2-3 hours) - Quickest win for performance
2. **Service Worker Updates** (3-4 hours) - Critical for user experience
3. **Database Indexes** (2-3 hours) - Measurable performance improvement
4. **Bundle Size Monitoring** (3-4 hours) - Prevents future regression
5. **WASM Worker Fix** (4-6 hours) - Biggest performance gain but most complex

**Total Estimated Effort:** 15-22 hours across all remaining P1 tasks

---

## Success Metrics

### Image Lazy Loading
- ✅ Lighthouse Performance score >90
- ✅ LCP <2.5s
- ✅ Initial page load 30-40% smaller

### Service Worker Updates
- ✅ Users see update notification within 5 minutes
- ✅ Zero reports of "stale code" issues
- ✅ >80% of users on latest version within 24h

### Database Indexes
- ✅ Liberation list query <30ms (10x faster)
- ✅ Venue filtering <50ms (5x faster)
- ✅ Date range queries <50ms (5x faster)

### Bundle Size Monitoring
- ✅ CI fails on budget overrun
- ✅ Bundle size tracked over time
- ✅ Developers notified of regressions

### WASM Worker Fix
- ✅ Worker loads without errors
- ✅ 3-5x performance improvement vs JS fallback
- ✅ Memory usage stable (no leaks)

---

**Document Version:** 1.0
**Last Updated:** January 25, 2026
**Status:** Ready for Implementation
