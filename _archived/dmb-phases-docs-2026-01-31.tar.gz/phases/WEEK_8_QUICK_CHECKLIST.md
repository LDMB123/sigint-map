# Week 8 Production Deployment - Quick Checklist

**Status**: 🚨 BLOCKED - Fix WASM issue first
**Time to Production**: 10 hours after WASM fix

---

## 🚨 CRITICAL BLOCKER (Fix First)

### WASM Module Issue

**Problem**: Build uses 19KB test module instead of 119KB production module

**Quick Fix** (30 minutes):

1. Edit `scripts/build-wasm.sh` line 20:
   ```bash
   --out-name dmb_wasm_aggregations  # Changed from 'index'
   ```

2. Edit `src/lib/wasm/loader.js` line 103:
   ```javascript
   await import('$lib/wasm/aggregations/dmb_wasm_aggregations.js')
   ```

3. Rebuild:
   ```bash
   ./scripts/build-wasm.sh
   rm app/src/lib/wasm/aggregations/index*
   npm run build
   npm test
   ```

4. Verify:
   ```bash
   find build -name "*.wasm" -type f -ls
   # Should show ~119KB file
   ```

**Full Details**: See `WEEK_8_WASM_FIX_GUIDE.md`

---

## Pre-Deployment

### Tests (10 min)
- [ ] `npm test` - All 1,765 tests pass
- [ ] `npm run test:e2e:smoke` - E2E smoke tests pass
- [ ] Performance test shows WASM ≥1.0x faster than JS

### Build Verification (5 min)
- [ ] `npm run build` succeeds
- [ ] Build output contains 119KB WASM file (not 19KB)
- [ ] No build warnings about WASM

---

## Staging Deployment

### Deploy (30 min)
- [ ] Deploy to staging environment
- [ ] Verify staging URL accessible
- [ ] Check WASM file loads: `curl -I https://staging/_app/immutable/assets/*.wasm`
- [ ] Verify `Content-Type: application/wasm` header

### Validation (30 min)
- [ ] Run Lighthouse audit (desktop + mobile)
  ```bash
  lighthouse https://staging --view
  ```
- [ ] PWA installability check (Chrome DevTools → Application)
- [ ] Service Worker installs and caches assets
- [ ] Offline mode works (DevTools → Network → Offline)

### Mobile Testing (2-4 hours)
- [ ] iOS Safari (iPhone 15 Pro)
  - [ ] PWA installs (Add to Home Screen)
  - [ ] WASM loads successfully
  - [ ] Offline mode works
  - [ ] Page load <3s on 4G

- [ ] Android Chrome (Pixel 8)
  - [ ] PWA installs
  - [ ] WASM loads
  - [ ] WebGPU fallback works
  - [ ] Offline mode works

---

## Production Setup

### Monitoring (2-4 hours)
- [ ] Configure error tracking (Sentry)
- [ ] Set up uptime monitoring (Pingdom/UptimeRobot)
- [ ] Configure log aggregation
- [ ] Set up performance budget alerts

### CDN Configuration (1 hour)
- [ ] WASM MIME type: `application/wasm`
- [ ] Cache headers for `/_app/immutable/*`:
  ```
  Cache-Control: public, max-age=31536000, immutable
  ```
- [ ] Enable Brotli compression
- [ ] Configure custom domain

---

## Production Deployment

### Pre-Deploy (15 min)
- [ ] Tag release in git: `git tag v1.0.0-week8`
- [ ] Backup current production (if applicable)
- [ ] Notify team of deployment window

### Deploy (30 min)
- [ ] Deploy to production
- [ ] Verify production URL
- [ ] Check WASM accessibility
- [ ] Verify CDN serving compressed assets

### Smoke Tests (15 min)
- [ ] Homepage loads without errors
- [ ] WASM module loads (DevTools Network tab)
- [ ] Service Worker installs
- [ ] Offline mode works
- [ ] Push notification permission prompt works

### Performance Validation (30 min)
- [ ] Run Lighthouse audit on production
  ```bash
  lighthouse https://your-domain.com --view
  ```
- [ ] Check Core Web Vitals
  - LCP < 2.5s
  - FID < 100ms
  - CLS < 0.1
- [ ] Verify WASM performance (compare to baseline)

---

## Post-Deployment

### Monitoring (24 hours)
- [ ] Check error rates (target: <0.1%)
- [ ] Monitor performance metrics
- [ ] Check cache hit rates
- [ ] Verify WASM load success rate >95%

### User Testing (48 hours)
- [ ] Test on multiple devices
- [ ] Gather user feedback
- [ ] Check analytics for issues
- [ ] Monitor social media mentions

---

## Target Scores

### Lighthouse
- Performance: ≥90
- Accessibility: ≥95
- Best Practices: 100
- SEO: 100
- PWA: ✓ Installable

### Core Web Vitals
- LCP: <2.5s (Good)
- FID: <100ms (Good)
- CLS: <0.1 (Good)

### Test Coverage
- Unit tests: 100% passing
- E2E tests: 100% passing
- Performance tests: All passing

---

## Rollback Plan

If critical issues occur:

1. **Immediate** (5 min):
   ```bash
   # Revert to previous deployment
   # Or disable service worker
   ```

2. **Check logs** for error patterns

3. **Notify team** via Slack/email

4. **Post-mortem** within 24 hours

---

## Contact Information

- **DevOps**: [contact info]
- **On-Call**: [contact info]
- **Status Page**: [URL]

---

## Resources

- Full Report: `WEEK_8_PRODUCTION_READINESS_REPORT.md`
- WASM Fix: `WEEK_8_WASM_FIX_GUIDE.md`
- Test Results: `npm test` output
- Build Output: `build/` directory

---

**Last Updated**: 2026-01-30
**Next Review**: After WASM fix
