# Svelte Store Patterns Reference

Quick reference guide for Svelte store patterns used in the DMB Almanac application.

---

## Pattern 1: Custom Store with Actions

**Use When**: You need complex state management with multiple coordinated actions

**Example**: `navigation.js`

```javascript
/**
 * @typedef {Object} NavigationState
 * @property {boolean} isNavigating
 * @property {string | null} currentUrl
 */

export const navigationStore = (() => {
  const { subscribe, set, update } = writable(initialState);

  return {
    subscribe, // Required for Svelte store contract
    set,       // Direct state updates
    update,    // Transformation-based updates

    // Custom actions
    async goBack() {
      update(state => ({ ...state, isNavigating: true }));
      try {
        await navigateBack();
      } finally {
        update(state => ({ ...state, isNavigating: false }));
      }
    },

    refresh() {
      set({
        isNavigating: false,
        currentUrl: getCurrentUrl()
      });
    }
  };
})();
```

**Usage**:
```svelte
<script>
  import { navigationStore } from '$stores/navigation';

  async function handleBack() {
    await navigationStore.goBack();
  }
</script>

{#if $navigationStore.isNavigating}
  <div>Navigating...</div>
{/if}
```

**Benefits**:
- ✅ Encapsulated logic
- ✅ Clean API
- ✅ Full state access in actions
- ✅ Type-safe with JSDoc

---

## Pattern 2: Selective Subscriptions

**Use When**: Large state object where components only care about specific parts

**Example**: `pwa.js`

```javascript
// Individual stores for granular control
const isSupported = writable(false);
const isReady = writable(false);
const hasUpdate = writable(false);
const isOffline = writable(false);

export const pwaStore = {
  // Expose only subscribe for each store
  isSupported: { subscribe: isSupported.subscribe },
  isReady: { subscribe: isReady.subscribe },
  hasUpdate: { subscribe: hasUpdate.subscribe },
  isOffline: { subscribe: isOffline.subscribe },

  // Methods modify internal stores
  async initialize() {
    isReady.set(true);
  },

  async updateServiceWorker() {
    hasUpdate.set(false);
    // ... update logic
  }
};

// Combined store for convenience
export const pwaState = derived(
  [isSupported, isReady, hasUpdate, isOffline],
  ([$supported, $ready, $update, $offline]) => ({
    isSupported: $supported,
    isReady: $ready,
    hasUpdate: $update,
    isOffline: $offline
  })
);
```

**Usage**:
```svelte
<script>
  import { pwaStore, pwaState } from '$stores/pwa';

  // Option 1: Subscribe to individual value
  const hasUpdate = pwaStore.hasUpdate; // Only re-renders on hasUpdate change

  // Option 2: Subscribe to combined state
  const state = pwaState; // Re-renders on any change
</script>

<!-- Option 1: Optimized -->
{#if $hasUpdate}
  <button on:click={() => pwaStore.updateServiceWorker()}>
    Update Available
  </button>
{/if}

<!-- Option 2: Convenient -->
{#if $pwaState.hasUpdate}
  <button on:click={() => pwaStore.updateServiceWorker()}>
    Update Available
  </button>
{/if}
```

**Benefits**:
- ✅ **Performance**: Components only re-render on relevant changes
- ✅ **Flexibility**: Choose individual or combined subscriptions
- ✅ **Scalability**: Easy to add new state fields

---

## Pattern 3: Non-Blocking Initialization

**Use When**: Heavy async operations during app startup

**Example**: `data.js`

```javascript
export const status = writable('loading');
export const progress = writable({ percentage: 0, phase: 'idle' });

export const dataStore = {
  status: { subscribe: status.subscribe },
  progress: { subscribe: progress.subscribe },

  initialize() {
    // Returns immediately - doesn't block
    import('$db/dexie/data-loader')
      .then(async ({ loadInitialData }) => {
        await loadInitialData((loadProgress) => {
          // Progress updates via store subscription
          progress.set(loadProgress);
        });
        status.set('ready');
      })
      .catch(err => {
        status.set('error');
      });
    // Function returns here, initialization continues in background
  }
};
```

**Usage**:
```svelte
<script>
  import { onMount } from 'svelte';
  import { dataStore, status, progress } from '$stores/data';

  onMount(() => {
    dataStore.initialize(); // Returns immediately
    // Component renders loading screen while data loads
  });
</script>

{#if $status === 'loading'}
  <div class="loading">
    Loading... {$progress.percentage}%
    <progress value={$progress.percentage} max="100" />
  </div>
{:else if $status === 'ready'}
  <div>Ready!</div>
{/if}
```

**Benefits**:
- ✅ **Non-blocking**: UI renders immediately
- ✅ **Progressive**: Shows real-time progress
- ✅ **Resilient**: Handles errors gracefully
- ✅ **Performance**: Doesn't block onMount

---

## Pattern 4: Derived Stores

**Use When**: You need computed values based on other stores

```javascript
import { derived } from 'svelte/store';

// Base stores
export const currentEntry = writable(null);
export const entries = writable([]);

// Derived stores - automatically update
export const currentUrl = derived(
  currentEntry,
  $entry => $entry?.url || ''
);

export const historySize = derived(
  entries,
  $entries => $entries.length
);

// Multi-store derivation
export const canNavigateBack = derived(
  [currentEntry, entries],
  ([$current, $entries]) => {
    return $current && $entries.indexOf($current) > 0;
  }
);
```

**Usage**:
```svelte
<script>
  import { currentUrl, historySize } from '$stores/navigation';
</script>

<div>Current: {$currentUrl}</div>
<div>History: {$historySize} entries</div>
```

**Benefits**:
- ✅ **Automatic**: Updates when dependencies change
- ✅ **Memoized**: Only recomputes when needed
- ✅ **Clean**: No manual update logic
- ✅ **Type-safe**: Full type inference

---

## Pattern 5: Store with Cleanup

**Use When**: Stores need to clean up resources (event listeners, timers, etc.)

```javascript
let eventCleanup = null;

export const myStore = {
  subscribe: writable(initialValue).subscribe,

  initialize() {
    const handleEvent = () => { /* ... */ };
    window.addEventListener('resize', handleEvent);

    // Return cleanup function
    eventCleanup = () => {
      window.removeEventListener('resize', handleEvent);
    };

    return eventCleanup;
  },

  cleanup() {
    eventCleanup?.();
  }
};
```

**Usage**:
```svelte
<script>
  import { onMount, onDestroy } from 'svelte';
  import { myStore } from '$stores/myStore';

  onMount(() => {
    const cleanup = myStore.initialize();
    return cleanup; // Svelte calls this on component destroy
  });
</script>
```

**Benefits**:
- ✅ **Clean**: Prevents memory leaks
- ✅ **Svelte-friendly**: Returns cleanup function
- ✅ **Safe**: Multiple initialization calls handled

---

## Pattern 6: AbortController Pattern

**Use When**: Multiple event listeners need coordinated cleanup

**Example**: `pwa.js`

```javascript
let globalAbortController = null;

export const pwaStore = {
  async initialize() {
    // Cleanup previous initialization
    globalAbortController?.abort();

    // Create new controller
    globalAbortController = new AbortController();
    const signal = globalAbortController.signal;

    // All listeners use same signal
    window.addEventListener('online', handleOnline, { signal });
    window.addEventListener('offline', handleOffline, { signal });

    return () => {
      globalAbortController?.abort(); // Removes ALL listeners
    };
  }
};
```

**Benefits**:
- ✅ **Centralized**: One abort removes all listeners
- ✅ **Safe**: Re-initialization automatically cleans up
- ✅ **Modern**: Uses standard AbortController API

---

## JSDoc Type Patterns

### Store Type Annotations

```javascript
/**
 * Writable store
 * @type {import('svelte/store').Writable<boolean>}
 */
const myStore = writable(false);

/**
 * Readable/Derived store
 * @type {import('svelte/store').Readable<string>}
 */
export const computed = derived(myStore, $value => String($value));
```

### Custom Store Types

```javascript
/**
 * Store with custom methods
 * @typedef {Object} CustomStore
 * @property {(fn: (value: T) => void) => () => void} subscribe
 * @property {(value: T) => void} set
 * @property {() => void} customMethod
 */
```

### State Shape Types

```javascript
/**
 * @typedef {Object} AppState
 * @property {boolean} isLoading
 * @property {string | null} error
 * @property {User[]} users
 */

/** @type {import('svelte/store').Writable<AppState>} */
const appStore = writable(initialState);
```

---

## Best Practices

### DO ✅

1. **Export both stores and derived values**
   ```javascript
   export const myStore = writable(0);
   export const doubled = derived(myStore, $v => $v * 2);
   ```

2. **Use selective subscriptions for performance**
   ```javascript
   // Good: Only re-renders on hasUpdate change
   const hasUpdate = pwaStore.hasUpdate;
   ```

3. **Return cleanup functions from initialize**
   ```javascript
   initialize() {
     // setup...
     return () => { /* cleanup */ };
   }
   ```

4. **Document store contracts with JSDoc**
   ```javascript
   /**
    * @typedef {Object} MyStore
    * @property {() => void} initialize
    * @property {() => void} cleanup
    */
   ```

5. **Use derived stores for computed values**
   ```javascript
   export const fullName = derived(
     [firstName, lastName],
     ([$first, $last]) => `${$first} ${$last}`
   );
   ```

### DON'T ❌

1. **Don't subscribe to entire state if you only need one value**
   ```javascript
   // Bad: Re-renders on ANY state change
   const state = myStore;

   // Good: Only re-renders on value change
   const value = derived(myStore, $state => $state.value);
   ```

2. **Don't forget cleanup functions**
   ```javascript
   // Bad: Memory leak
   window.addEventListener('resize', handler);

   // Good: Cleanup
   const cleanup = () => {
     window.removeEventListener('resize', handler);
   };
   ```

3. **Don't block onMount with initialization**
   ```javascript
   // Bad: Blocks UI
   onMount(async () => {
     await heavyOperation(); // UI frozen
   });

   // Good: Non-blocking
   onMount(() => {
     store.initialize(); // Returns immediately
   });
   ```

4. **Don't use writable where derived is appropriate**
   ```javascript
   // Bad: Manual updates needed
   const doubled = writable(0);
   myStore.subscribe($v => doubled.set($v * 2));

   // Good: Automatic updates
   const doubled = derived(myStore, $v => $v * 2);
   ```

---

## Performance Tips

### 1. Selective Subscriptions
```javascript
// Instead of subscribing to entire object
const state = appStore; // Re-renders on ANY change

// Subscribe to specific values
const isLoading = derived(appStore, $s => $s.isLoading);
```

### 2. Batch Updates
```javascript
// Bad: Multiple re-renders
myStore.set(1);
myStore.set(2);
myStore.set(3);

// Good: Single re-render
myStore.update(v => v + 3);
```

### 3. Memoize Expensive Computations
```javascript
// Derived stores are memoized automatically
export const expensiveValue = derived(myStore, $v => {
  // This only runs when $v changes
  return expensiveComputation($v);
});
```

### 4. Use Shallow Equality for Objects
```javascript
// Prevent re-renders when object reference changes but values don't
import { derived } from 'svelte/store';

export const myDerived = derived(myStore, ($v, set) => {
  const newValue = computeValue($v);
  // Only set if value actually changed
  if (JSON.stringify(newValue) !== JSON.stringify($v)) {
    set(newValue);
  }
});
```

---

## Testing Stores

### Unit Testing
```javascript
import { get } from 'svelte/store';
import { myStore } from './myStore';

test('store updates correctly', () => {
  myStore.set(5);
  expect(get(myStore)).toBe(5);
});

test('derived store computes correctly', () => {
  myStore.set(10);
  expect(get(doubled)).toBe(20);
});
```

### Integration Testing
```javascript
import { render } from '@testing-library/svelte';
import MyComponent from './MyComponent.svelte';
import { myStore } from '$stores/myStore';

test('component updates with store', async () => {
  const { getByText } = render(MyComponent);

  myStore.set(5);
  await tick();

  expect(getByText('5')).toBeInTheDocument();
});
```

---

## Migration from TypeScript

### Before (TypeScript)
```typescript
interface MyState {
  value: number;
  error: string | null;
}

export const myStore = writable<MyState>({
  value: 0,
  error: null
});
```

### After (JavaScript + JSDoc)
```javascript
/**
 * @typedef {Object} MyState
 * @property {number} value
 * @property {string | null} error
 */

/** @type {import('svelte/store').Writable<MyState>} */
export const myStore = writable({
  value: 0,
  error: null
});
```

**Result**: Same type safety, same autocomplete, more documentation

---

## References

- **Svelte Stores**: https://svelte.dev/docs/svelte-store
- **JSDoc Types**: https://www.typescriptlang.org/docs/handbook/jsdoc-supported-types.html
- **TypeScript JSDoc**: https://www.typescriptlang.org/docs/handbook/type-checking-javascript-files.html

---

## Store Files in This Project

1. **`navigation.js`** - Custom store with actions pattern
2. **`pwa.js`** - Selective subscriptions with AbortController pattern
3. **`data.js`** - Non-blocking initialization pattern
4. **`dexie.ts`** - (To be converted) Complex IndexedDB store

---

**Last Updated**: 2026-01-26
**Patterns Used**: 6
**Converted Stores**: 3
**Status**: Production Ready ✅
