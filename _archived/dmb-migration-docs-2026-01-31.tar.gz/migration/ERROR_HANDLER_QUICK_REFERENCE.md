# Error Handler JavaScript Quick Reference

Fast reference for using the converted error handling system.

## Quick Import Guide

```javascript
// Error types and classes
import {
  AppError,
  ApiError,
  ComponentLoadError,
  AsyncError,
  ValidationError,
  NetworkError,
  TimeoutError,
  DatabaseError,
  StoreError,
  TelemetryError,
  NavigationError,
  isAppError,
  isApiError,
  toAppError
} from '$lib/errors/types.js';

// Error logger
import {
  errorLogger,
  enableVerboseLogging,
  getDiagnosticReport
} from '$lib/errors/logger.js';

// Error handler
import {
  handleError,
  retryOperation,
  withErrorHandling,
  setupGlobalErrorHandlers
} from '$lib/errors/handler.js';
```

## Common Patterns

### 1. Creating Custom Errors

```javascript
// API error
throw new ApiError('/api/songs', 'GET', 'Not found', 404);

// Component load error
throw new ComponentLoadError('LazyComponent', new Error('Failed to load'));

// Validation error
throw new ValidationError({
  email: ['Invalid email format'],
  password: ['Must be at least 8 characters']
});

// Network error
throw new NetworkError('Connection failed');

// Timeout error
throw new TimeoutError('fetchData', 5000);
```

### 2. Logging Errors

```javascript
// Simple logging
errorLogger.debug('Cache hit', { key: 'songs' });
errorLogger.info('Data loaded', { count: 100 });
errorLogger.warn('Slow query', undefined, { duration: 5000 });
errorLogger.error('Database query failed', error, { table: 'songs' });
errorLogger.fatal('Critical system failure', error);

// Specialized logging
errorLogger.logAsyncError('loadData', error, { dataType: 'songs' });
errorLogger.logApiError('/api/songs', 'GET', 500, error);
```

### 3. Handling Errors

```javascript
// Generic error handling
try {
  await riskyOperation();
} catch (error) {
  const result = handleError(error);
  console.log(result.userMessage); // User-friendly message
  console.log(result.canRetry); // Whether retry is possible
  console.log(result.suggestion); // Suggested action
}
```

### 4. Retry with Exponential Backoff

```javascript
// Retry up to 3 times with exponential backoff
const data = await retryOperation(
  () => fetchData(),
  3,           // max retries
  1000,        // initial delay (1s)
  { operation: 'fetchData' }
);
```

### 5. Wrapping Functions with Error Handling

```javascript
// Automatically log errors from async functions
const safeFetch = withErrorHandling(
  async (url) => fetch(url),
  { operation: 'fetch' }
);

// Use the wrapped function
const response = await safeFetch('/api/songs');
```

### 6. Global Error Handlers

```javascript
// Setup once in your app initialization
setupGlobalErrorHandlers();
```

### 7. Type Guards

```javascript
try {
  // some operation
} catch (error) {
  if (isAppError(error)) {
    console.log(error.code, error.statusCode);
  }

  if (isApiError(error)) {
    console.log(error.endpoint, error.method);
  }
}
```

### 8. Error Conversion

```javascript
try {
  // operation that might throw any error
} catch (error) {
  // Convert to AppError for consistent handling
  const appError = toAppError(error, 'OPERATION_FAILED');
  throw appError;
}
```

### 9. Development Helpers

```javascript
// Enable verbose logging in development
if (import.meta.env.DEV) {
  enableVerboseLogging();
}

// Get diagnostic report
const report = getDiagnosticReport();
console.log(report.errorCount);
console.log(report.warningCount);
console.log(report.recentErrors);
```

### 10. Register Custom Error Handlers

```javascript
// Send errors to external monitoring service
errorLogger.onError(async (report) => {
  await fetch('/api/telemetry/errors', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(report)
  });
});
```

## Error Handler Results

Every `handleError()` call returns:

```javascript
{
  handled: boolean,      // Whether error was handled
  message: string,       // Technical message
  userMessage: string,   // User-friendly message
  canRetry: boolean,     // Whether operation can be retried
  suggestion?: string    // Suggested user action
}
```

## HTTP Status Code Mapping

| Status | Error Code | canRetry |
|--------|-----------|----------|
| 400 | INVALID_REQUEST | false |
| 401 | UNAUTHORIZED | false |
| 403 | FORBIDDEN | false |
| 404 | NOT_FOUND | false |
| 408 | TIMEOUT_ERROR | true |
| 429 | RATE_LIMITED | true |
| 500+ | SERVER_ERROR | true |
| 503 | NETWORK_ERROR | true |

## Log Levels

| Level | Console | Production | Use Case |
|-------|---------|------------|----------|
| debug | ✅ | ❌ | Development debugging |
| info | ✅ | ❌ | General information |
| warn | ✅ | ✅ | Warnings that need attention |
| error | ✅ | ✅ | Errors requiring logging |
| fatal | ✅ | ✅ | Critical errors requiring immediate action |

## Security Best Practices

✅ **Stack traces only in development**
```javascript
// Automatic - controlled by isDev flag
const isDev = process.env.NODE_ENV === 'development';
```

✅ **Sanitized error messages**
```javascript
// Never expose sensitive data in user messages
userMessage: 'Database query failed'  // ✅ Good
userMessage: `Query failed: ${sql}`   // ❌ Bad - might expose structure
```

✅ **Context filtering**
```javascript
// Only log necessary context
errorLogger.error('Login failed', error, {
  userId: user.id,        // ✅ Good
  password: password      // ❌ Never log credentials
});
```

## Performance Tips

1. **Use appropriate log levels** - Don't log debug in production
2. **Batch error reports** - Use errorLogger.onError() with batching
3. **Limit context size** - Keep context objects small
4. **Clean up logs** - errorLogger.clearLogs() periodically
5. **Set log limits** - Default 100, adjust if needed

## Common Anti-Patterns to Avoid

❌ **Don't swallow errors**
```javascript
try {
  await operation();
} catch (error) {
  // Silent failure - bad!
}
```

✅ **Do log errors**
```javascript
try {
  await operation();
} catch (error) {
  errorLogger.error('Operation failed', error);
  throw error; // Re-throw or handle
}
```

❌ **Don't log sensitive data**
```javascript
errorLogger.error('Auth failed', error, {
  password: password  // Never log credentials
});
```

✅ **Do sanitize context**
```javascript
errorLogger.error('Auth failed', error, {
  username: username,  // OK to log non-sensitive data
  attemptCount: count
});
```

❌ **Don't create errors in loops without rate limiting**
```javascript
for (const item of items) {
  errorLogger.error('Processing failed', error);  // Spam!
}
```

✅ **Do batch or rate limit**
```javascript
let errorCount = 0;
for (const item of items) {
  try {
    await process(item);
  } catch (error) {
    errorCount++;
  }
}
if (errorCount > 0) {
  errorLogger.error(`Batch processing failed: ${errorCount} errors`);
}
```

## File Locations

```
src/lib/errors/
├── types.js      (11 KB) - Error classes and type guards
├── logger.js     (11 KB) - Structured logging
├── handler.js    (11 KB) - Error routing and recovery
├── types.ts      (8 KB)  - TypeScript original (to be removed)
├── logger.ts     (8 KB)  - TypeScript original (to be removed)
└── handler.ts    (9 KB)  - TypeScript original (to be removed)
```

## Need More Help?

- **Full Documentation**: See `ERROR_HANDLER_JS_CONVERSION_COMPLETE.md`
- **Source Code**: All files have comprehensive JSDoc
- **Examples**: Check `@example` tags in JSDoc comments
- **Security**: All security best practices documented in completion report
